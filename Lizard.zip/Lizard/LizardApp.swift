import SwiftUI

@main
struct LizardApp: App {
    init() {
        // Keep audio working even in Silent mode / while mixing with others
        AudioSession.configure()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
