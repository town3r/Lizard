import SpriteKit
internal import CoreMotion   // quiets the implicit access warning

// 🔔 Notify ContentView every time a lizard is created
extension Notification.Name {
    static let lizardSpawned = Notification.Name("LizardSpawned")
}

final class LizardScene: SKScene {

    // MARK: Tuning
    private let gravityDown: CGFloat = -9.8
    private let maxPhysicsLizards = 300
    private let baseLizardSize: CGFloat = 80
    private let lifetime: TimeInterval = 10

    // MARK: Nodes/Assets
    private let physicsLayer = SKNode()
    private var lizardTexture: SKTexture?

    // MARK: Debug overlay
    private let fpsLabel = SKLabelNode(fontNamed: "Menlo")
    private var smoothedDT: Double = 1.0 / 60.0
    private var lastUpdate: TimeInterval = 0
    private(set) var currentFPS: Double = 60

    // MARK: Lifetime pause
    private var agingPaused = false

    // MARK: Tilt
    private let motionMgr = CMMotionManager()
    private var tiltEnabled = false

    // MARK: Lifecycle
    override func didMove(to view: SKView) {
        super.didMove(to: view)

        backgroundColor = .white
        view.allowsTransparency = true
        view.ignoresSiblingOrder = true
        view.shouldCullNonVisibleNodes = true
        view.isAsynchronous = true
        view.preferredFramesPerSecond = 120   // ProMotion

        physicsWorld.gravity = CGVector(dx: 0, dy: gravityDown)
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.categoryBitMask = 0x1 << 1

        addChild(physicsLayer)
        prepareAssets(on: view)
        setupFPSOverlay()

        SoundPlayer.shared.preload(name: "lizard", ext: "wav", voices: 6)
    }

    override func didChangeSize(_ oldSize: CGSize) {
        super.didChangeSize(oldSize)
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.categoryBitMask = 0x1 << 1
        layoutFPSOverlay()
    }

    // MARK: Public API ---------------------------------------------------------

    func clearAll() {
        physicsLayer.removeAllActions()
        physicsLayer.removeAllChildren()
    }

    /// Pause/resume the lifetime actions (physics keeps running).
    func setAgingPaused(_ paused: Bool) {
        agingPaused = paused
        physicsLayer.children.forEach { $0.speed = paused ? 0 : 1 }
    }

    func emitBurstFromCenter(countRange: ClosedRange<Int>) {
        guard size != .zero else { return }
        let count = Int.random(in: countRange)
        for _ in 0..<count {
            spawnLizard(
                at: CGPoint(x: size.width/2, y: size.height * 0.55),
                impulse: CGVector(dx: CGFloat.random(in: -150...150),
                                  dy: CGFloat.random(in: 140...280)),
                scale: CGFloat.random(in: 0.7...1.1),
                playSound: true
            )
        }
    }

    func emitFromCircleCenterRandom(sizeJitter: CGFloat) {
        guard size != .zero else { return }
        spawnLizard(
            at: CGPoint(x: size.width/2, y: size.height * 0.55),
            impulse: CGVector(dx: CGFloat.random(in: -90...90),
                              dy: CGFloat.random(in: 120...220)),
            scale: CGFloat.random(in: max(0.4, 1.0 - sizeJitter)...(1.0 + sizeJitter)),
            playSound: true
        )
    }

    func rainOnce() {
        for _ in 0..<16 { rainStep() }
    }

    func rainStep() {
        guard size != .zero else { return }
        if currentFPS < 80 || physicsLayer.children.count > maxPhysicsLizards - 10 { return }

        let x = CGFloat.random(in: 30...(size.width - 30))
        let y = size.height - 2
        let impulse = CGVector(dx: CGFloat.random(in: -40...40),
                               dy: CGFloat.random(in: -10...30))
        spawnLizard(
            at: CGPoint(x: x, y: y),
            impulse: impulse,
            scale: CGFloat.random(in: 0.45...0.9),
            playSound: false
        )
    }

    // Tilt control
    func startTilt() {
        guard motionMgr.isDeviceMotionAvailable else { return }
        tiltEnabled = true
        motionMgr.deviceMotionUpdateInterval = 1.0 / 60.0
        // Portrait-friendly frame
        motionMgr.startDeviceMotionUpdates(using: .xArbitraryZVertical, to: .main) { [weak self] motion, _ in
            guard let self, self.tiltEnabled, let m = motion else { return }
            let gScale: CGFloat = 9.8
            // Your confirmed mapping: keep gravity.y as-is (no minus)
            let gx = CGFloat(m.gravity.x) * gScale
            let gy = CGFloat(m.gravity.y) * gScale
            self.physicsWorld.gravity = CGVector(dx: gx, dy: gy)
        }
    }

    func stopTilt() {
        tiltEnabled = false
        motionMgr.stopDeviceMotionUpdates()
        physicsWorld.gravity = CGVector(dx: 0, dy: gravityDown)
    }

    // MARK: Internals ----------------------------------------------------------

    private func prepareAssets(on view: SKView) {
        guard lizardTexture == nil else { return }
        let label = SKLabelNode(text: "🦎")
        label.fontSize = baseLizardSize
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        if let tex = view.texture(from: label) {
            tex.filteringMode = .nearest
            lizardTexture = tex
        } else {
            let dot = SKShapeNode(circleOfRadius: baseLizardSize * 0.5)
            dot.fillColor = .systemGreen
            dot.strokeColor = .clear
            lizardTexture = view.texture(from: dot)
        }
    }

    private func spawnLizard(at point: CGPoint,
                             impulse: CGVector,
                             scale: CGFloat,
                             playSound: Bool) {

        if playSound { SoundPlayer.shared.play(name: "lizard", ext: "wav") }

        if physicsLayer.children.count >= maxPhysicsLizards {
            physicsLayer.children.first?.removeFromParent()
        }

        let node: SKSpriteNode
        if let t = lizardTexture {
            node = SKSpriteNode(texture: t, size: CGSize(width: baseLizardSize, height: baseLizardSize))
        } else {
            node = SKSpriteNode(color: .systemGreen, size: CGSize(width: baseLizardSize, height: baseLizardSize))
        }

        node.name = "lizard"
        node.setScale(scale)
        node.position = point
        node.zPosition = 1
        node.speed = agingPaused ? 0 : 1
        physicsLayer.addChild(node)
        NotificationCenter.default.post(name: .lizardSpawned, object: nil)   // notify UI

        let radius = (baseLizardSize * 0.45) * scale
        let body = SKPhysicsBody(circleOfRadius: radius)
        body.affectedByGravity = true
        body.usesPreciseCollisionDetection = false
        body.mass = 0.08
        body.restitution = 0.25
        body.friction = 0.8
        body.linearDamping = 0.1
        node.physicsBody = body

        body.applyImpulse(impulse)

        node.run(.sequence([
            .wait(forDuration: lifetime),
            .fadeOut(withDuration: 0.25),
            .removeFromParent()
        ]))
    }

    // MARK: FPS overlay
    private func setupFPSOverlay() {
        fpsLabel.fontSize = 12
        fpsLabel.fontColor = .white
        fpsLabel.alpha = 0.9
        fpsLabel.zPosition = 9999
        fpsLabel.horizontalAlignmentMode = .right
        fpsLabel.verticalAlignmentMode = .top
        addChild(fpsLabel)
        layoutFPSOverlay()
    }

    private func layoutFPSOverlay() {
        fpsLabel.position = CGPoint(x: size.width - 8, y: size.height - 8)
    }

    override func update(_ currentTime: TimeInterval) {
        if lastUpdate == 0 { lastUpdate = currentTime }
        let dt = max(0.0001, currentTime - lastUpdate)
        lastUpdate = currentTime

        let alpha = 0.15
        smoothedDT = smoothedDT * (1 - alpha) + dt * alpha
        currentFPS = 1.0 / smoothedDT

        fpsLabel.text = String(format: "%.0f FPS", currentFPS.rounded())
    }
}
