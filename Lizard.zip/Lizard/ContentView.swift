import SwiftUI
import SpriteKit
import AVFoundation
import GameKit

struct ContentView: View {
    // Dark/Light mode
    @Environment(\.colorScheme) private var colorScheme

    // SpriteKit scene
    @State private var scene = LizardScene(size: .zero)

    // Stats (persisted)
    @AppStorage("totalLizardsSpawned") private var totalSpawned = 0
    @AppStorage("mainButtonTaps") private var mainButtonTaps = 0

    // Hold logic
    @State private var isPressingMain = false
    @State private var spewTimer: Timer?
    @State private var rainTimer: Timer?

    // Game Center Leaderboards
    private let lbTotalLizards = "com.town3r.lizard.totalspawned"
    private let lbButtonTaps  = "com.town3r.lizard.buttontaps"

    var body: some View {
        GeometryReader { proxy in
            let size = proxy.size

            ZStack {
                // SPRITEKIT
                SpriteView(
                    scene: scene,
                    preferredFramesPerSecond: 120,
                    options: [.ignoresSiblingOrder, .shouldCullNonVisibleNodes],
                    debugOptions: []
                )
                .ignoresSafeArea()
                .background(colorScheme == .dark ? Color.black : Color.white) // SwiftUI background
                .allowsHitTesting(false)

                // TOP-LEFT: HUD (counters + trophy w/ menu)
                VStack(alignment: .leading, spacing: 6) {
                    Text("🦎 \(totalSpawned)")
                        .font(.system(size: 14, weight: .semibold, design: .monospaced))
                    Text("🔘 \(mainButtonTaps)")
                        .font(.system(size: 14, weight: .regular, design: .monospaced))

                    Button("🏆") {
                        // Default tap: show overall Game Center leaderboards view
                        GameCenterManager.shared.presentLeaderboards()
                    }
                    .contextMenu {
                        Button("View Lizards Leaderboard") {
                            GameCenterManager.shared.presentLeaderboards(leaderboardID: lbTotalLizards)
                        }
                        Button("View Button Taps Leaderboard") {
                            GameCenterManager.shared.presentLeaderboards(leaderboardID: lbButtonTaps)
                        }
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10))
                }
                .padding(.top, 12)
                .padding(.leading, 12)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)

                // TOP-RIGHT: Clear (trash) button
                Button("🗑️") { scene.clearAll() }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10))
                    .padding(.top, 12)
                    .padding(.trailing, 12)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)

                // CENTER: Circle button (tap = 1 lizard, hold = fountain)
                Button {
                    mainButtonTaps += 1
                    scene.setAgingPaused(false)
                    scene.emitFromCircleCenterRandom(sizeJitter: 0.2)
                    SoundPlayer.shared.play(name: "lizard", ext: "wav")
                    reportScoresIfReady()
                } label: {
                    ZStack {
                        Circle()
                            .fill(.ultraThinMaterial)
                            .overlay(Circle().stroke(Color.white.opacity(0.6), lineWidth: 0.8))
                            .frame(width: 240, height: 240)
                            .shadow(color: Color.black.opacity(0.18), radius: 10, x: 0, y: 6)
                        Image("lizard")
                            .resizable()
                            .scaledToFit()
                            .clipShape(Circle())
                            .padding(20)
                    }
                }
                .frame(width: 240, height: 240)
                .position(x: size.width * 0.5, y: size.height * 0.55)
                .simultaneousGesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { _ in
                            guard !isPressingMain else { return }
                            isPressingMain = true
                            startSpewHold()
                        }
                        .onEnded { _ in
                            isPressingMain = false
                            stopSpewHold()
                        }
                )

                // BOTTOM: Make it Rain + Stop
                VStack {
                    HStack(spacing: 12) {
                        Button {
                            scene.setAgingPaused(false)
                            scene.rainOnce()
                            reportScoresIfReady()
                        } label: {
                            Text("🦎 Make it Rain 🦎")
                                .font(.system(size: 20, weight: .bold))
                                .padding(.vertical, 14)
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.plain)
                        .background(
                            RoundedRectangle(cornerRadius: 20, style: .continuous)
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white.opacity(0.6), lineWidth: 0.8)
                                )
                                .shadow(color: Color.black.opacity(0.18), radius: 10, x: 0, y: 6)
                        )
                        .simultaneousGesture(
                            LongPressGesture(minimumDuration: .infinity)
                                .onChanged { _ in
                                    scene.setAgingPaused(false)
                                    startRainHold()
                                }
                                .onEnded { _ in stopRainHold() }
                        )

                        Button {
                            stopRainHold()
                            scene.setAgingPaused(true)
                        } label: {
                            Text("🛑")
                                .font(.system(size: 24))
                                .padding(.vertical, 14)
                                .frame(maxWidth: 60)
                        }
                        .buttonStyle(.plain)
                        .background(
                            RoundedRectangle(cornerRadius: 20, style: .continuous)
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.white.opacity(0.6), lineWidth: 0.8)
                                )
                                .shadow(color: Color.black.opacity(0.18), radius: 10, x: 0, y: 6)
                        )
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 10)
                }
                .frame(maxHeight: .infinity, alignment: .bottom)
            }
            // === Lifecycle hooks ===
            .onAppear {
                // Scene setup
                scene.scaleMode = .resizeFill
                scene.size = size
                scene.startTilt()
                scene.backgroundColor = (colorScheme == .dark) ? .black : .white

                // Game Center auth (older style you're using)
                GameCenterManager.shared.authenticate { topViewController() }

                // Optional: start TestFlight screenshot feedback if you added it
                BetaFeedbackManager.shared.start()
            }
            .onChange(of: size) { _, newSize in
                scene.size = newSize
            }
            .onChange(of: colorScheme) { _, newScheme in
                scene.backgroundColor = (newScheme == .dark) ? .black : .white
            }
            .onDisappear {
                scene.stopTilt()
                BetaFeedbackManager.shared.stop()
            }
            .onReceive(NotificationCenter.default.publisher(for: .lizardSpawned)) { _ in
                totalSpawned += 1
                reportScoresIfReady()
            }
        }
    }

    // MARK: - Hold logic
    private func startSpewHold() {
        spewTimer?.invalidate()
        scene.setAgingPaused(false)
        spewTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { _ in
            scene.emitFromCircleCenterRandom(sizeJitter: 0.6)
            SoundPlayer.shared.play(name: "lizard", ext: "wav")
        }
        if let spewTimer { RunLoop.main.add(spewTimer, forMode: .common) }
    }
    private func stopSpewHold() { spewTimer?.invalidate(); spewTimer = nil }

    private func startRainHold() {
        rainTimer?.invalidate()
        rainTimer = Timer.scheduledTimer(withTimeInterval: 0.08, repeats: true) { _ in
            scene.rainStep()
        }
        if let rainTimer { RunLoop.main.add(rainTimer, forMode: .common) }
    }
    private func stopRainHold() { rainTimer?.invalidate(); rainTimer = nil }

    // MARK: - Game Center reporting (both leaderboards)
    private func reportScoresIfReady() {
        GameCenterManager.shared.report(scores: [
            (id: lbTotalLizards, value: totalSpawned),
            (id: lbButtonTaps,  value: mainButtonTaps)
        ])
        GameCenterManager.shared.reportAchievements(totalSpawned: totalSpawned,
                                                    buttonTaps: mainButtonTaps)
    }
}
