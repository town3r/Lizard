//
//  GameCenterManager.swift
//  Lizard
//

import Foundation
import Combine
import GameKit
import UIKit

final class GameCenterManager: NSObject, ObservableObject {
    static let shared = GameCenterManager()
    @Published var isAuthenticated = false

    // Call once (e.g., in ContentView.onAppear)
    func authenticate(presenting viewControllerProvider: @escaping () -> UIViewController?) {
        let lp = GKLocalPlayer.local
        lp.authenticateHandler = { [weak self] gcVC, _ in
            if let gcVC, let presenter = viewControllerProvider() {
                presenter.present(gcVC, animated: true)
                return
            }
            self?.isAuthenticated = lp.isAuthenticated
        }
    }

    // MARK: - Scores

    /// Submit a single score (kept for compatibility)
    func report(score: Int, leaderboardID: String) {
        report(scores: [(leaderboardID, score)])
    }

    /// Submit multiple scores to multiple leaderboards.
    func report(scores: [(id: String, value: Int)]) {
        guard GKLocalPlayer.local.isAuthenticated else { return }

        for (id, value) in scores {
            GKLeaderboard.submitScore(
                value,
                context: 0,
                player: GKLocalPlayer.local,
                leaderboardIDs: [id]     // modern multi-ID API takes an array
            ) { error in
                if let error { print("GK submit score error for \(id):", error) }
            }
        }
    }

    // MARK: - Achievements

    struct AchIDs {
        static let firstLizard       = "ach.first_lizard"
        static let hundredLizards    = "ach.hundred_lizards"
        static let thousandLizards   = "ach.thousand_lizards"
        static let tenKLizards       = "ach.tenk_lizards"
        static let buttonMasher      = "ach.button_masher"
    }

    func reportAchievements(totalSpawned: Int, buttonTaps: Int) {
        guard GKLocalPlayer.local.isAuthenticated else { return }

        var arr: [GKAchievement] = []

        func update(_ id: String, progress: Double) {
            let a = GKAchievement(identifier: id)
            a.percentComplete = min(100, max(0, progress))
            a.showsCompletionBanner = true
            arr.append(a)
        }

        update(AchIDs.firstLizard,     progress: totalSpawned >= 1 ? 100 : Double(totalSpawned) / 1.0 * 100)
        update(AchIDs.hundredLizards,  progress: Double(totalSpawned) / 100.0 * 100)
        update(AchIDs.thousandLizards, progress: Double(totalSpawned) / 1_000.0 * 100)
        update(AchIDs.tenKLizards,     progress: Double(totalSpawned) / 10_000.0 * 100)
        update(AchIDs.buttonMasher,    progress: Double(buttonTaps) / 100.0 * 100)

        GKAchievement.report(arr) { error in
            if let error { print("GK achievement report error:", error) }
        }
    }
}

// MARK: - Presentation helpers

extension GameCenterManager: GKGameCenterControllerDelegate {
    /// Present leaderboards. Pass a specific ID to jump right to that board.
    func presentLeaderboards(leaderboardID: String? = nil) {
        guard GKLocalPlayer.local.isAuthenticated else { return }

        // Using GKGameCenterViewController (works on iOS 18, may be deprecated in later SDKs)
        let vc = GKGameCenterViewController(state: .leaderboards)
        vc.gameCenterDelegate = self
        vc.leaderboardIdentifier = leaderboardID
        topViewController()?.present(vc, animated: true)
    }

    func presentAchievements() {
        guard GKLocalPlayer.local.isAuthenticated else { return }
        let vc = GKGameCenterViewController(state: .achievements)
        vc.gameCenterDelegate = self
        topViewController()?.present(vc, animated: true)
    }

    // Delegate
    func gameCenterViewControllerDidFinish(_ gameCenterViewController: GKGameCenterViewController) {
        gameCenterViewController.dismiss(animated: true)
    }
}

// MARK: - VC helper

func topViewController() -> UIViewController? {
    guard let scene = UIApplication.shared.connectedScenes
        .compactMap({ $0 as? UIWindowScene }).first,
          let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return nil }
    var top = root
    while let presented = top.presentedViewController { top = presented }
    return top
}
