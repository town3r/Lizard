//
//  BetaFeedbackManager.swift
//  Lizard
//
//  Created by Ben Towne on 8/16/25.
//

import UIKit
import MessageUI

@MainActor
final class BetaFeedbackManager: NSObject {
    static let shared = BetaFeedbackManager()

    private var isObserving = false

    // MARK: Public API
    func start() {
        guard !isObserving else { return }
        isObserving = true
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleScreenshot),
            name: UIApplication.userDidTakeScreenshotNotification,
            object: nil
        )
    }

    func stop() {
        guard isObserving else { return }
        isObserving = false
        NotificationCenter.default.removeObserver(self,
            name: UIApplication.userDidTakeScreenshotNotification,
            object: nil
        )
    }

    // MARK: Handler
    @objc private func handleScreenshot() {
        if isTestFlightBuild {
            // TestFlight automatically presents Apple’s Beta Feedback prompt
            // when a screenshot is taken in a TestFlight build.
            // We can show a tiny heads-up so users aren’t confused.
            presentToast("Thanks! TestFlight will open feedback.")
        } else {
            // Local / App Store: present our own email feedback with screenshot attached.
            presentEmailFeedback()
        }
    }

    // MARK: Utilities

    /// A best-effort check commonly used to tell TestFlight/dev vs App Store.
    private var isTestFlightBuild: Bool {
        guard let receipt = Bundle.main.appStoreReceiptURL?.lastPathComponent else { return false }
        // "sandboxReceipt" for TestFlight & debug; "receipt" for App Store.
        return receipt == "sandboxReceipt"
    }

    /// Capture the current UI as an image (without touching Photos).
    private func captureScreenshot() -> UIImage? {
        guard let scene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene }).first,
              let window = scene.windows.first(where: { $0.isKeyWindow }) else {
            return nil
        }
        let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
        return renderer.image { _ in
            window.drawHierarchy(in: window.bounds, afterScreenUpdates: false)
        }
    }

    private func presentEmailFeedback() {
        guard let top = topViewController() else { return }

        let subject = "Lizard Beta Feedback"
        let body = """
        Please describe what you were doing and what went wrong (or right!).\
        \n\nDevice: \(UIDevice.current.model) (\(UIDevice.current.systemName) \(UIDevice.current.systemVersion))\
        \nApp Version: \(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?") (\(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "?"))
        """

        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["support@yourdomain.com"])  // <— change this
            mail.setSubject(subject)
            mail.setMessageBody(body, isHTML: false)

            if let img = captureScreenshot(),
               let data = img.jpegData(compressionQuality: 0.8) {
                mail.addAttachmentData(data, mimeType: "image/jpeg", fileName: "screenshot.jpg")
            }
            top.present(mail, animated: true)
        } else {
            // Fallback: open mailto
            var urlString = "mailto:support@yourdomain.com?subject=\(subject)&body=\(body)"
            // URL-encode
            urlString = urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? urlString
            if let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            } else {
                presentToast("Couldn't open Mail.")
            }
        }
    }

    private func presentToast(_ message: String, duration: TimeInterval = 1.6) {
        guard let top = topViewController() else { return }
        let label = PaddingLabel()
        label.text = message
        label.textColor = .white
        label.font = .systemFont(ofSize: 14, weight: .semibold)
        label.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        label.numberOfLines = 2
        label.layer.cornerRadius = 10
        label.layer.masksToBounds = true
        label.translatesAutoresizingMaskIntoConstraints = false

        top.view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: top.view.centerXAnchor),
            label.bottomAnchor.constraint(equalTo: top.view.safeAreaLayoutGuide.bottomAnchor, constant: -24)
        ])

        UIView.animate(withDuration: 0.25, delay: duration, options: []) {
            label.alpha = 0
        } completion: { _ in
            label.removeFromSuperview()
        }
    }
}

// MARK: - Helpers

private func topViewController() -> UIViewController? {
    guard let scene = UIApplication.shared.connectedScenes
        .compactMap({ $0 as? UIWindowScene }).first,
          let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return nil }
    var top = root
    while let presented = top.presentedViewController { top = presented }
    return top
}

private final class PaddingLabel: UILabel {
    var insets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: insets))
    }
    override var intrinsicContentSize: CGSize {
        let s = super.intrinsicContentSize
        return CGSize(width: s.width + insets.left + insets.right,
                      height: s.height + insets.top + insets.bottom)
    }
}

// MARK: - Mail delegate

extension BetaFeedbackManager: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController,
                               didFinishWith result: MFMailComposeResult,
                               error: Error?) {
        controller.dismiss(animated: true)
    }
}
